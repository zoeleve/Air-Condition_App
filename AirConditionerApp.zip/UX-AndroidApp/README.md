# UX-AndroidApp
School project during the course of Human–computer interaction
